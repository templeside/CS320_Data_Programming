# project: p4
# submitter: cjhon
# partner: none
# hours: 20

import pandas as pd
import re

# need to delete for problem
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver

options = Options()
options.headless = True
service = Service(executable_path="chromium.chromedriver")
b = webdriver.Chrome(options=options, service=service)
# need to delete for problem

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt



import pandas as pd
import time
from flask import Flask, request, jsonify, Response

app = Flask(__name__)
df = pd.read_csv("main.csv")

clickCounter = {
    "count": 0,
    "styleA":0,
    "styleB": 0,
    "clickedA":0,
    "clickedB":0,
    "CtrA": 0, 
    "CtrB":0
}

@app.route("/dashboard_1.svg")
def svg1():
    args = dict(request.args)
    if('cmap' in args):
        cmapColo = args['cmap']
        
#     dashboard_1.svg
    fig, ax = plt.subplots()
    dates = df['Purchase date'].unique()
    formatted_dates = dates[0:len(dates): 15]

    if('cmap' in args):
        cmapColo = 'plasma'
        ax.scatter(df['Purchase date'], df['Purchase time'].astype('datetime64').dt.hour, c=df["Total amount"], cmap=cmapColo)
        ax.set_title("Scatter plot of Purchase date vs hour. Amount in KRW")
        
    else:
        cmapColo = "bone"
        ax.scatter(df['Purchase date'], df['Purchase time'].astype('datetime64').dt.hour, c=df["Total amount"], cmap=cmapColo)
        ax.set_title("Scatter plot of Purchase date vs hour")
        
    ax.set_xlabel("Purchase date")
    ax.set_ylabel("Purchase hour(24h)")
    ax.set_xticks(formatted_dates)
    ax.set_xticklabels(formatted_dates, rotation = 10)
    
    plt.savefig('dashboard_1.svg')
    plt.close(fig)
    
    with open("dashboard_1.svg") as f:
        return Response(f.read(),headers={"Content-Type": "image/svg+xml"})
        
        
@app.route("/dashboard_2.svg")
def svg2():
    fig, ax = plt.subplots()
    times = pd.to_datetime(df['Purchase time'])
    grouped_data = df.groupby([times.dt.hour])

    total_day = times.max() - times.min()
    total_day.days

    hourly_sum = grouped_data.sum()[['Net return']]
    hourly_average = hourly_sum/total_day.days

    ax.bar(hourly_average.index.values,hourly_average['Net return'] )
    ax.set_xlabel("Purchase hour(24h)")
    ax.set_ylabel("Average net return(krw)")
    ax.set_title("Bar graph of average hour net return(KRW)")
    
    plt.savefig('dashboard_2.svg')
    plt.close(fig)
    with open("dashboard_2.svg") as f:
        return Response(f.read(),headers={"Content-Type": "image/svg+xml"})
    
clickCounter["count"] = 0

@app.route('/')
def home():
    global clickCounter

    with open("index.html") as f:
        html = f.read()
        
# #     dashboard_1.svg
#     cmapColo = "bone"
#     fig, ax = plt.subplots()
#     dates = df['Purchase date'].unique()
#     formatted_dates = dates[0:len(dates): 15]

#     ax.scatter(df['Purchase date'], df['Purchase time'].astype('datetime64').dt.hour, c=df["Total amount"], cmap=cmapColo)

#     ax.set_title("Scatter plot of Purchase date vs hour")
#     ax.set_xlabel("Purchase date")
#     ax.set_ylabel("Purchase hour(24h)")
#     ax.set_xticks(formatted_dates)
#     ax.set_xticklabels(formatted_dates, rotation = 10)
    
#     plt.savefig('dashboard_1.svg')
#     plt.close(fig)
    

#     dashboard_2.svg
#     fig, ax = plt.subplots()
#     times = pd.to_datetime(df['Purchase time'])
#     grouped_data = df.groupby([times.dt.hour])

#     total_day = times.max() - times.min()
#     total_day.days

#     hourly_sum = grouped_data.sum()[['Net return']]
#     hourly_average = hourly_sum/total_day.days

#     ax.bar(hourly_average.index.values,hourly_average['Net return'] )
#     ax.set_xlabel("Purchase hour(24h)")
#     ax.set_ylabel("Average net return(krw)")
#     ax.set_title("Bar graph of average hour net return(KRW)")
    
#     plt.savefig('dashboard_2.svg')
#     plt.close(fig)
        
        
    clickCounter["count"] = clickCounter["count"]+1
#     print("current count is "+ str(clickCounter["count"]))
    
    if(clickCounter["count"]<=10):
        if(clickCounter["count"]%2 ==0):
            # do something with A style - red
            
            html = html.replace('<a href="donate.html" target="_blank">Donate</a>',
                                '<a href="donate.html?from=A" target="_blank" style="color:red;"><b>Donate</b></a>' )
            clickCounter['styleA'] +=1
        else:
            # do something with B style - blue
            html = html.replace('<a href="donate.html" target="_blank">Donate</a>',
                                '<a href="donate.html?from=B" target="_blank" style="color:blue;"><b>Donate</b></a>' )
            clickCounter['styleB'] +=1
    #after 10 counts
    else:
        if(clickCounter['CtrA']>= clickCounter['CtrB']):
#             # do something with A style
            html = html.replace('<a href="donate.html" target="_blank">Donate</a>',
                                '<a href="donate.html?from=A" target="_blank" style="color:red;"><b>Donate</b></a>' )
            clickCounter['styleA'] +=1

        else:
#             # do something with B style
            html = html.replace('<a href="donate.html" target="_blank">Donate</a>',
                                '<a href="donate.html?from=B" target="_blank" style="color:blue;"><b>Donate</b></a>' )
            clickCounter['styleB'] +=1

    return html

@app.route('/browse.html')
def browse():
#     fonts: https://www.w3schools.com/cssref/tryit.asp?filename=trycss_font_timesnewroman
    df_html = df.to_html()
    return "<html>{}<html>".format("<h1>Browse</h1>"+df_html) 

last_visit = {}
@app.route('/browse.json')
def browse_json():
#     print(request.remote_addr)
#     print(type(request.remote_addr))
    ip = request.remote_addr
    
    time_limit = 3
    if(ip in last_visit and (time.time()- last_visit[ip] <time_limit)):
        return Response("Too many requests, come back after", status=429, headers={"Retry-After":time_limit})
    
    last_visit[ip] = time.time()
    return jsonify(df.to_dict())

@app.route('/donate.html')
def donate():    
    global clickCounter

    with open("donate.html") as f:
        html = f.read()
        
    args = dict(request.args)
    if('from' in args and args['from'] == 'A'):
        clickCounter['clickedA'] +=1
        clickCounter['CtrA'] = clickCounter['clickedA']/ clickCounter['styleA']
    elif('from' in args and args['from'] == 'B'):
        clickCounter['clickedB'] +=1
        clickCounter['CtrB'] = clickCounter['clickedB']/ clickCounter['styleB']
    
    return html

@app.route('/email', methods=["POST"])
def email():
    email = str(request.data, "utf-8")
    
    #if valid email
    if(re.match('^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$', email)):
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email+"\n")

        with open("emails.txt", "r") as f: # open file in read mode to check number
            num_subscribed = len(f.readlines())            

        return jsonify(f"thanks, you're subscriber number {num_subscribed}!")
    
    #if not valid email
    else:
        return jsonify("Invalid email...")

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False) # don't change this line!
